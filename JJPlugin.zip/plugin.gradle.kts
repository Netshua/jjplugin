dependencies {
    implementation("com.aliucord:api:0.3.3"),
    implementation("io.github.micwagga:numero-por-extenso:1.0.1")
}

description = "Rsrs.. Sole qualquer div!"
version = "1.0.1"