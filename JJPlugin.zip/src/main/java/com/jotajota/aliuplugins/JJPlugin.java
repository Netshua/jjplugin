package com.jotajota.aliuplugins;

import android.content.Context;
import com.aliucord.annotations.AliucordPlugin;
import com.aliucord.entities.Plugin;
import com.aliucord.api.CommandsAPI;
import com.aliucord.plugins.NumExt;
import java.util.ArrayList; // Added import for ArrayList

@SuppressWarnings("unused")
@AliucordPlugin
public class JJPlugin extends Plugin {
    @Override
    public void start(Context context) {
        CommandsAPI commands = CommandsAPI.getInstance();
        commands.registerCommand("jj", "Envia números em extenso", new ArrayList<>(), (ctx, args) -> {
            StringBuilder message = new StringBuilder();
            for (int i = 1; i <= 10; i++) {
                String numeroExtenso = NumExt.getInstance().convert((long) i).toUpperCase();
                message.append(numeroExtenso).append(" !");
            }
            ctx.reply(message.toString());
        });
    }

    @Override
    public void stop(Context context) {
        CommandsAPI commands = CommandsAPI.getInstance();
        commands.unregisterAll();
    }
}